import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Package, Plus, Trash2, Edit } from "lucide-react";
import { getInsumos, saveInsumo, deleteInsumo, Insumo } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

const Insumos = () => {
  const [insumos, setInsumos] = useState<Insumo[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState<{
    nome: string;
    tipo: "fertilizante" | "defensivo" | "sementes" | "outros";
    quantidade: string;
    unidade: string;
    fornecedor: string;
    dataCompra: string;
    valorUnitario: string;
  }>({
    nome: "",
    tipo: "fertilizante",
    quantidade: "",
    unidade: "",
    fornecedor: "",
    dataCompra: "",
    valorUnitario: "",
  });

  useEffect(() => {
    loadInsumos();
  }, []);

  const loadInsumos = () => {
    setInsumos(getInsumos());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nome || !formData.quantidade || !formData.unidade || !formData.fornecedor || !formData.dataCompra || !formData.valorUnitario) {
      toast({
        title: "Erro de validação",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    const quantidade = parseFloat(formData.quantidade);
    const valorUnitario = parseFloat(formData.valorUnitario);
    
    if (isNaN(quantidade) || quantidade <= 0 || isNaN(valorUnitario) || valorUnitario <= 0) {
      toast({
        title: "Erro de validação",
        description: "Quantidade e valor devem ser números positivos",
        variant: "destructive",
      });
      return;
    }

    const insumo: Insumo = {
      id: editingId || Date.now().toString(),
      nome: formData.nome,
      tipo: formData.tipo,
      quantidade,
      unidade: formData.unidade,
      fornecedor: formData.fornecedor,
      dataCompra: formData.dataCompra,
      valorUnitario,
    };

    saveInsumo(insumo);
    loadInsumos();
    resetForm();

    toast({
      title: editingId ? "Insumo atualizado" : "Insumo cadastrado",
      description: `${formData.nome} foi ${editingId ? "atualizado" : "cadastrado"} com sucesso`,
    });
  };

  const handleEdit = (insumo: Insumo) => {
    setFormData({
      nome: insumo.nome,
      tipo: insumo.tipo,
      quantidade: insumo.quantidade.toString(),
      unidade: insumo.unidade,
      fornecedor: insumo.fornecedor,
      dataCompra: insumo.dataCompra,
      valorUnitario: insumo.valorUnitario.toString(),
    });
    setEditingId(insumo.id);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir este insumo?")) {
      deleteInsumo(id);
      loadInsumos();
      toast({
        title: "Insumo excluído",
        description: "O insumo foi removido com sucesso",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      nome: "",
      tipo: "fertilizante",
      quantidade: "",
      unidade: "",
      fornecedor: "",
      dataCompra: "",
      valorUnitario: "",
    });
    setEditingId(null);
    setIsFormOpen(false);
  };

  const tipoColors = {
    fertilizante: "bg-primary",
    defensivo: "bg-destructive",
    sementes: "bg-success",
    outros: "bg-secondary",
  };

  const tipoLabels = {
    fertilizante: "Fertilizante",
    defensivo: "Defensivo",
    sementes: "Sementes",
    outros: "Outros",
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Insumos</h1>
          <p className="text-muted-foreground">Controle seu estoque de insumos</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Novo Insumo
        </Button>
      </div>

      {isFormOpen && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? "Editar" : "Novo"} Insumo</CardTitle>
            <CardDescription>Preencha os dados do insumo</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome *</Label>
                  <Input
                    id="nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    placeholder="Ex: NPK 10-10-10"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tipo">Tipo *</Label>
                  <Select
                    value={formData.tipo}
                    onValueChange={(value: any) => setFormData({ ...formData, tipo: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fertilizante">Fertilizante</SelectItem>
                      <SelectItem value="defensivo">Defensivo</SelectItem>
                      <SelectItem value="sementes">Sementes</SelectItem>
                      <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="quantidade">Quantidade *</Label>
                  <Input
                    id="quantidade"
                    type="number"
                    step="0.01"
                    value={formData.quantidade}
                    onChange={(e) => setFormData({ ...formData, quantidade: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unidade">Unidade *</Label>
                  <Input
                    id="unidade"
                    value={formData.unidade}
                    onChange={(e) => setFormData({ ...formData, unidade: e.target.value })}
                    placeholder="Ex: kg, L, sacas"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fornecedor">Fornecedor *</Label>
                  <Input
                    id="fornecedor"
                    value={formData.fornecedor}
                    onChange={(e) => setFormData({ ...formData, fornecedor: e.target.value })}
                    placeholder="Nome do fornecedor"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataCompra">Data da Compra *</Label>
                  <Input
                    id="dataCompra"
                    type="date"
                    value={formData.dataCompra}
                    onChange={(e) => setFormData({ ...formData, dataCompra: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="valorUnitario">Valor Unitário (R$) *</Label>
                  <Input
                    id="valorUnitario"
                    type="number"
                    step="0.01"
                    value={formData.valorUnitario}
                    onChange={(e) => setFormData({ ...formData, valorUnitario: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button type="submit">{editingId ? "Atualizar" : "Cadastrar"}</Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {insumos.length === 0 ? (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Package className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhum insumo cadastrado</p>
            </CardContent>
          </Card>
        ) : (
          insumos.map((insumo) => (
            <Card key={insumo.id} className="hover-scale">
              <CardHeader>
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Package className="h-4 w-4 text-secondary" />
                      <span className="truncate">{insumo.nome}</span>
                    </CardTitle>
                    <CardDescription className="truncate">{insumo.fornecedor}</CardDescription>
                  </div>
                  <Badge className={tipoColors[insumo.tipo]}>{tipoLabels[insumo.tipo]}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-sm">
                  <span className="text-muted-foreground">Quantidade: </span>
                  <span className="font-medium">
                    {insumo.quantidade} {insumo.unidade}
                  </span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Valor unitário: </span>
                  <span>R$ {insumo.valorUnitario.toFixed(2)}</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Valor total: </span>
                  <span className="font-medium">
                    R$ {(insumo.quantidade * insumo.valorUnitario).toFixed(2)}
                  </span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Compra: </span>
                  <span>{new Date(insumo.dataCompra).toLocaleDateString()}</span>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(insumo)}>
                    <Edit className="h-3 w-3 mr-1" />
                    Editar
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(insumo.id)}
                  >
                    <Trash2 className="h-3 w-3 mr-1" />
                    Excluir
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default Insumos;
