import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { BookOpen, Code2, Rocket, FolderTree, CheckCircle2, Users, Lock, Smartphone } from "lucide-react";

const Documentacao = () => {
  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Documentação</h1>
        <p className="text-muted-foreground">Guia completo do AgroPocket</p>
      </div>

      {/* Visão Geral */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <CardTitle>Visão Geral do Projeto</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            O <strong>AgroPocket</strong> é um sistema web desenvolvido para gestão de dados agrícolas, 
            permitindo o controle completo de plantações, insumos, colheitas e histórico de operações.
          </p>
          <div className="bg-muted/50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Características Principais:</h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
              <li>Sistema completo de autenticação (login e cadastro)</li>
              <li>Interface responsiva para mobile, tablet e desktop</li>
              <li>Captura e validação de dados em formulários intuitivos</li>
              <li>Exibição dinâmica de informações em tempo real</li>
              <li>Persistência de dados usando LocalStorage</li>
              <li>Proteção de rotas e sessão persistente</li>
              <li>Feedback visual para todas as ações do usuário</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Autenticação */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-primary" />
            <CardTitle>Sistema de Autenticação</CardTitle>
          </div>
          <CardDescription>Acesso seguro e controle de usuários</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <h4 className="font-semibold">Cadastro de Usuários</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Nome completo obrigatório</li>
                <li>Email com validação</li>
                <li>Senha mínima de 6 caracteres</li>
                <li>Confirmação de senha</li>
                <li>Redirecionamento para login após cadastro</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Login e Segurança</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Validação de credenciais</li>
                <li>Sessão persistente</li>
                <li>Proteção de todas as rotas</li>
                <li>Logout seguro</li>
                <li>Redirecionamento automático</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Responsividade */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Smartphone className="h-5 w-5 text-primary" />
            <CardTitle>Design Responsivo</CardTitle>
          </div>
          <CardDescription>Otimizado para todos os dispositivos</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <h4 className="font-semibold">📱 Mobile ({"<"} 768px)</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Menu hambúrguer lateral</li>
                <li>Cards empilhados</li>
                <li>Botões touch-friendly</li>
                <li>Formulários otimizados</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">💻 Tablet (768px - 1024px)</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Layout em grid adaptativo</li>
                <li>Navegação compacta</li>
                <li>Uso eficiente do espaço</li>
                <li>Interações otimizadas</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">🖥️ Desktop ({">"} 1024px)</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Menu horizontal completo</li>
                <li>Múltiplas colunas</li>
                <li>Densidade otimizada</li>
                <li>Experiência desktop completa</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Instalação */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Rocket className="h-5 w-5 text-primary" />
            <CardTitle>Instalação e Execução Local</CardTitle>
          </div>
          <CardDescription>Como executar o projeto em sua máquina</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div>
              <h4 className="font-semibold mb-2">1. Pré-requisitos:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li>Node.js (versão 18 ou superior)</li>
                <li>npm ou yarn instalado</li>
              </ul>
            </div>
            
            <Separator />
            
            <div>
              <h4 className="font-semibold mb-2">2. Instalação:</h4>
              <div className="bg-muted p-4 rounded-lg font-mono text-sm space-y-2">
                <div># Clone o repositório (se aplicável)</div>
                <div>git clone [url-do-repositorio]</div>
                <div className="mt-2"># Navegue até a pasta</div>
                <div>cd AgroPocket</div>
                <div className="mt-2"># Instale as dependências</div>
                <div>npm install</div>
              </div>
            </div>
            
            <Separator />
            
            <div>
              <h4 className="font-semibold mb-2">3. Executar o Projeto:</h4>
              <div className="bg-muted p-4 rounded-lg font-mono text-sm space-y-2">
                <div># Inicie o servidor de desenvolvimento</div>
                <div>npm run dev</div>
                <div className="mt-2"># Acesse no navegador:</div>
                <div>http://localhost:8080</div>
              </div>
            </div>

            <Separator />
            
            <div>
              <h4 className="font-semibold mb-2">4. Primeiro Acesso:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li>Você será redirecionado para a página de autenticação</li>
                <li>Clique em "Cadastrar" para criar sua conta</li>
                <li>Preencha nome, email e senha (mínimo 6 caracteres)</li>
                <li>Após o cadastro, faça login para ter acesso completo ao sistema</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tecnologias */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Code2 className="h-5 w-5 text-primary" />
            <CardTitle>Tecnologias Utilizadas</CardTitle>
          </div>
          <CardDescription>Stack tecnológico do projeto</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <h4 className="font-semibold">Frontend:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>React 18</li>
                <li>TypeScript</li>
                <li>Vite (build tool)</li>
                <li>React Router DOM</li>
                <li>TanStack Query</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">UI/UX:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Tailwind CSS (responsivo)</li>
                <li>shadcn/ui components</li>
                <li>Radix UI primitives</li>
                <li>Lucide React (ícones)</li>
                <li>Sonner (toasts)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estrutura */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <FolderTree className="h-5 w-5 text-primary" />
            <CardTitle>Estrutura do Projeto</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <code className="text-xs bg-muted p-4 rounded block whitespace-pre font-mono">
            {`agrodatahub/
├── src/
│   ├── components/
│   │   ├── ui/              # Componentes shadcn/ui
│   │   ├── Layout.tsx       # Layout responsivo
│   │   └── ProtectedRoute.tsx # Proteção de rotas
│   ├── lib/
│   │   ├── auth.ts          # Sistema de autenticação
│   │   ├── storage.ts       # Persistência de dados
│   │   └── utils.ts         # Utilitários
│   ├── pages/
│   │   ├── Auth.tsx         # Login e cadastro
│   │   ├── Dashboard.tsx    # Página principal
│   │   ├── Plantacoes.tsx   # Gerenciamento
│   │   ├── Insumos.tsx      # Controle
│   │   ├── Colheitas.tsx    # Registro
│   │   ├── Historico.tsx    # Histórico
│   │   └── Documentacao.tsx # Esta página
│   ├── hooks/
│   │   ├── use-toast.ts     # Notificações
│   │   └── use-mobile.tsx   # Detecção mobile
│   ├── App.tsx              # Rotas e proteção
│   └── index.css            # Estilos globais
└── package.json             # Dependências`}
          </code>
        </CardContent>
      </Card>

      {/* Funcionalidades */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-primary" />
            <CardTitle>Funcionalidades Implementadas</CardTitle>
          </div>
          <CardDescription>Recursos e requisitos atendidos</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            <li className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <strong>Autenticação</strong> - Sistema completo de login e cadastro
                <div className="text-sm text-muted-foreground mt-1">Progresso atual: 100% ✓</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <strong>Responsividade</strong> - Interface adaptável para todos os dispositivos
                <div className="text-sm text-muted-foreground mt-1">Progresso atual: 100% ✓</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <strong>Dashboard</strong> - Visão geral com métricas em tempo real
                <div className="text-sm text-muted-foreground mt-1">Progresso atual: 90%</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <strong>Plantações</strong> - Gerenciamento completo de cultivos
                <div className="text-sm text-muted-foreground mt-1">Progresso atual: 95%</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <strong>Insumos</strong> - Controle de estoque e valores
                <div className="text-sm text-muted-foreground mt-1">Progresso atual: 95%</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <strong>Colheitas</strong> - Registro de produtividade
                <div className="text-sm text-muted-foreground mt-1">Progresso atual: 95%</div>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <strong>Histórico</strong> - Rastreamento de operações
                <div className="text-sm text-muted-foreground mt-1">Progresso atual: 90%</div>
              </div>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Guia de Uso */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            <CardTitle>Guia de Uso</CardTitle>
          </div>
          <CardDescription>Passo a passo para utilizar o sistema</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">1. Primeiro Acesso</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li>Acesse a aplicação no navegador</li>
                <li>Na página de login, clique em "Cadastrar"</li>
                <li>Preencha: nome, email e senha (mínimo 6 caracteres)</li>
                <li>Confirme sua senha</li>
                <li>Após o cadastro, faça login com suas credenciais</li>
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-2">2. Navegação no Sistema</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li><strong>Desktop:</strong> Use o menu horizontal no topo da página</li>
                <li><strong>Mobile:</strong> Clique no ícone de menu (☰) no canto superior direito</li>
                <li>Acesse seu perfil clicando no ícone de usuário</li>
                <li>Para sair, clique em "Sair" no menu do usuário</li>
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-2">3. Gerenciar Plantações</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li>Acesse o menu "Plantações"</li>
                <li>Clique em "Nova Plantação"</li>
                <li>Preencha os dados: nome, área, data de plantio, etc.</li>
                <li>Clique em "Cadastrar Plantação"</li>
                <li>Visualize, edite ou exclua plantações existentes</li>
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-2">4. Controlar Insumos</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li>Navegue até "Insumos"</li>
                <li>Adicione fertilizantes, defensivos ou sementes</li>
                <li>Registre quantidade, fornecedor e valores</li>
                <li>Monitore o estoque e investimentos</li>
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-2">5. Registrar Colheitas</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li>Acesse "Colheitas"</li>
                <li>Clique em "Registrar Colheita"</li>
                <li>Vincule a uma plantação (opcional)</li>
                <li>Registre quantidade e qualidade</li>
                <li>Adicione observações relevantes</li>
              </ul>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-2">6. Consultar Histórico</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                <li>Visualize todas as operações em "Histórico"</li>
                <li>Veja data, hora e descrição de cada ação</li>
                <li>Acompanhe a evolução do seu sistema</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contato */}
      <Card className="border-primary">
        <CardHeader>
          <CardTitle>Contato e Suporte</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-sm">
            Para dúvidas, sugestões ou reportar problemas:
          </p>
          <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">
            <li>Email: suporte@agrodatahub.com</li>
            <li>GitHub: github.com/seu-usuario/agrodatahub</li>
            <li>Documentação: docs.agrodatahub.com</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default Documentacao;
