import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { TrendingUp, Plus, Trash2, Edit } from "lucide-react";
import { getColheitas, saveColheita, deleteColheita, Colheita, getPlantacoes } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

const Colheitas = () => {
  const [colheitas, setColheitas] = useState<Colheita[]>([]);
  const [plantacoes, setPlantacoes] = useState<any[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState<{
    plantacaoId: string;
    cultura: string;
    dataColheita: string;
    quantidade: string;
    unidade: string;
    qualidade: "excelente" | "boa" | "regular" | "ruim";
    observacoes: string;
  }>({
    plantacaoId: "",
    cultura: "",
    dataColheita: "",
    quantidade: "",
    unidade: "",
    qualidade: "boa",
    observacoes: "",
  });

  useEffect(() => {
    loadColheitas();
    loadPlantacoes();
  }, []);

  const loadColheitas = () => {
    setColheitas(getColheitas());
  };

  const loadPlantacoes = () => {
    setPlantacoes(getPlantacoes());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.cultura || !formData.dataColheita || !formData.quantidade || !formData.unidade) {
      toast({
        title: "Erro de validação",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    const quantidade = parseFloat(formData.quantidade);
    if (isNaN(quantidade) || quantidade <= 0) {
      toast({
        title: "Erro de validação",
        description: "Quantidade deve ser um número positivo",
        variant: "destructive",
      });
      return;
    }

    const colheita: Colheita = {
      id: editingId || Date.now().toString(),
      plantacaoId: formData.plantacaoId,
      cultura: formData.cultura,
      dataColheita: formData.dataColheita,
      quantidade,
      unidade: formData.unidade,
      qualidade: formData.qualidade,
      observacoes: formData.observacoes,
    };

    saveColheita(colheita);
    loadColheitas();
    resetForm();

    toast({
      title: editingId ? "Colheita atualizada" : "Colheita registrada",
      description: `Colheita de ${formData.cultura} foi ${editingId ? "atualizada" : "registrada"} com sucesso`,
    });
  };

  const handlePlantacaoChange = (plantacaoId: string) => {
    const plantacao = plantacoes.find((p) => p.id === plantacaoId);
    if (plantacao) {
      setFormData({
        ...formData,
        plantacaoId,
        cultura: plantacao.cultura,
      });
    }
  };

  const handleEdit = (colheita: Colheita) => {
    setFormData({
      plantacaoId: colheita.plantacaoId,
      cultura: colheita.cultura,
      dataColheita: colheita.dataColheita,
      quantidade: colheita.quantidade.toString(),
      unidade: colheita.unidade,
      qualidade: colheita.qualidade,
      observacoes: colheita.observacoes,
    });
    setEditingId(colheita.id);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta colheita?")) {
      deleteColheita(id);
      loadColheitas();
      toast({
        title: "Colheita excluída",
        description: "A colheita foi removida com sucesso",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      plantacaoId: "",
      cultura: "",
      dataColheita: "",
      quantidade: "",
      unidade: "",
      qualidade: "boa",
      observacoes: "",
    });
    setEditingId(null);
    setIsFormOpen(false);
  };

  const qualidadeColors = {
    excelente: "bg-success",
    boa: "bg-info",
    regular: "bg-warning",
    ruim: "bg-destructive",
  };

  const qualidadeLabels = {
    excelente: "Excelente",
    boa: "Boa",
    regular: "Regular",
    ruim: "Ruim",
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Colheitas</h1>
          <p className="text-muted-foreground">Monitore suas colheitas e produtividade</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Registrar Colheita
        </Button>
      </div>

      {isFormOpen && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? "Editar" : "Registrar"} Colheita</CardTitle>
            <CardDescription>Preencha os dados da colheita</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="plantacaoId">Plantação (opcional)</Label>
                  <Select value={formData.plantacaoId} onValueChange={handlePlantacaoChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma plantação" />
                    </SelectTrigger>
                    <SelectContent>
                      {plantacoes.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.cultura} - {p.variedade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cultura">Cultura *</Label>
                  <Input
                    id="cultura"
                    value={formData.cultura}
                    onChange={(e) => setFormData({ ...formData, cultura: e.target.value })}
                    placeholder="Ex: Milho, Soja, Trigo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataColheita">Data da Colheita *</Label>
                  <Input
                    id="dataColheita"
                    type="date"
                    value={formData.dataColheita}
                    onChange={(e) => setFormData({ ...formData, dataColheita: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="quantidade">Quantidade *</Label>
                  <Input
                    id="quantidade"
                    type="number"
                    step="0.01"
                    value={formData.quantidade}
                    onChange={(e) => setFormData({ ...formData, quantidade: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unidade">Unidade *</Label>
                  <Input
                    id="unidade"
                    value={formData.unidade}
                    onChange={(e) => setFormData({ ...formData, unidade: e.target.value })}
                    placeholder="Ex: kg, ton, sacas"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="qualidade">Qualidade</Label>
                  <Select
                    value={formData.qualidade}
                    onValueChange={(value: any) => setFormData({ ...formData, qualidade: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excelente">Excelente</SelectItem>
                      <SelectItem value="boa">Boa</SelectItem>
                      <SelectItem value="regular">Regular</SelectItem>
                      <SelectItem value="ruim">Ruim</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  id="observacoes"
                  value={formData.observacoes}
                  onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                  placeholder="Adicione observações sobre a colheita..."
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit">{editingId ? "Atualizar" : "Registrar"}</Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {colheitas.length === 0 ? (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhuma colheita registrada</p>
            </CardContent>
          </Card>
        ) : (
          colheitas.map((colheita) => (
            <Card key={colheita.id} className="hover-scale">
              <CardHeader>
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <TrendingUp className="h-4 w-4 text-success" />
                      <span className="truncate">{colheita.cultura}</span>
                    </CardTitle>
                    <CardDescription>
                      {new Date(colheita.dataColheita).toLocaleDateString()}
                    </CardDescription>
                  </div>
                  <Badge className={qualidadeColors[colheita.qualidade]}>
                    {qualidadeLabels[colheita.qualidade]}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-sm">
                  <span className="text-muted-foreground">Quantidade: </span>
                  <span className="font-medium">
                    {colheita.quantidade} {colheita.unidade}
                  </span>
                </div>
                {colheita.observacoes && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">Observações: </span>
                    <p className="mt-1 text-xs">{colheita.observacoes}</p>
                  </div>
                )}
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(colheita)}>
                    <Edit className="h-3 w-3 mr-1" />
                    Editar
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(colheita.id)}
                  >
                    <Trash2 className="h-3 w-3 mr-1" />
                    Excluir
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default Colheitas;
