import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sprout, Package, TrendingUp, Activity } from "lucide-react";
import { getPlantacoes, getInsumos, getColheitas, getHistorico } from "@/lib/storage";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalPlantacoes: 0,
    totalInsumos: 0,
    totalColheitas: 0,
    ultimasOperacoes: 0,
  });

  useEffect(() => {
    const loadStats = () => {
      const plantacoes = getPlantacoes();
      const insumos = getInsumos();
      const colheitas = getColheitas();
      const historico = getHistorico();

      setStats({
        totalPlantacoes: plantacoes.length,
        totalInsumos: insumos.length,
        totalColheitas: colheitas.length,
        ultimasOperacoes: historico.slice(0, 5).length,
      });
    };

    loadStats();
    // Refresh stats every 5 seconds
    const interval = setInterval(loadStats, 5000);
    return () => clearInterval(interval);
  }, []);

  const statCards = [
    {
      title: "Plantações Ativas",
      value: stats.totalPlantacoes,
      icon: Sprout,
      description: "Total de áreas plantadas",
      link: "/plantacoes",
      color: "text-primary",
    },
    {
      title: "Insumos Cadastrados",
      value: stats.totalInsumos,
      icon: Package,
      description: "Estoque de insumos",
      link: "/insumos",
      color: "text-secondary",
    },
    {
      title: "Colheitas Registradas",
      value: stats.totalColheitas,
      icon: TrendingUp,
      description: "Total de colheitas",
      link: "/colheitas",
      color: "text-success",
    },
    {
      title: "Operações Recentes",
      value: stats.ultimasOperacoes,
      icon: Activity,
      description: "Últimas atividades",
      link: "/historico",
      color: "text-info",
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-4xl font-bold text-foreground mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          Visão geral do seu sistema de gestão agrícola
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.title} className="hover-scale transition-all hover:shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
                <Icon className={`h-5 w-5 ${card.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{card.value}</div>
                <p className="text-xs text-muted-foreground mt-1">{card.description}</p>
                <Link to={card.link}>
                  <Button variant="link" className="px-0 mt-2" size="sm">
                    Ver detalhes →
                  </Button>
                </Link>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Bem-vindo ao AgroPocket</CardTitle>
            <CardDescription>
              Sistema completo de gestão agrícola
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              O AgroPocket é uma solução completa para gerenciar suas operações agrícolas:
            </p>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-primary"></div>
                <span>Registre e acompanhe suas plantações</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-secondary"></div>
                <span>Controle seu estoque de insumos</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-success"></div>
                <span>Monitore suas colheitas e produtividade</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-info"></div>
                <span>Acompanhe o histórico de operações</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
            <CardDescription>
              Acesse rapidamente as principais funcionalidades
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link to="/plantacoes">
              <Button className="w-full justify-start" variant="outline">
                <Sprout className="mr-2 h-4 w-4" />
                Nova Plantação
              </Button>
            </Link>
            <Link to="/insumos">
              <Button className="w-full justify-start" variant="outline">
                <Package className="mr-2 h-4 w-4" />
                Cadastrar Insumo
              </Button>
            </Link>
            <Link to="/colheitas">
              <Button className="w-full justify-start" variant="outline">
                <TrendingUp className="mr-2 h-4 w-4" />
                Registrar Colheita
              </Button>
            </Link>
            <Link to="/historico">
              <Button className="w-full justify-start" variant="outline">
                <Activity className="mr-2 h-4 w-4" />
                Ver Histórico
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
