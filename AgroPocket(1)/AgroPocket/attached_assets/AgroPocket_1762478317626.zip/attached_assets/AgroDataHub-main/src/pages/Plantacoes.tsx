import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sprout, Plus, Trash2, Edit } from "lucide-react";
import { getPlantacoes, savePlantacao, deletePlantacao, Plantacao } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

const Plantacoes = () => {
  const [plantacoes, setPlantacoes] = useState<Plantacao[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState<{
    cultura: string;
    area: string;
    dataPlantio: string;
    variedade: string;
    status: "plantado" | "crescimento" | "colhido";
    previsaoColheita: string;
  }>({
    cultura: "",
    area: "",
    dataPlantio: "",
    variedade: "",
    status: "plantado",
    previsaoColheita: "",
  });

  useEffect(() => {
    loadPlantacoes();
  }, []);

  const loadPlantacoes = () => {
    setPlantacoes(getPlantacoes());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!formData.cultura || !formData.area || !formData.dataPlantio || !formData.variedade || !formData.previsaoColheita) {
      toast({
        title: "Erro de validação",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive",
      });
      return;
    }

    const area = parseFloat(formData.area);
    if (isNaN(area) || area <= 0) {
      toast({
        title: "Erro de validação",
        description: "Área deve ser um número positivo",
        variant: "destructive",
      });
      return;
    }

    const plantacao: Plantacao = {
      id: editingId || Date.now().toString(),
      cultura: formData.cultura,
      area,
      dataPlantio: formData.dataPlantio,
      variedade: formData.variedade,
      status: formData.status,
      previsaoColheita: formData.previsaoColheita,
    };

    savePlantacao(plantacao);
    loadPlantacoes();
    resetForm();

    toast({
      title: editingId ? "Plantação atualizada" : "Plantação cadastrada",
      description: `${formData.cultura} foi ${editingId ? "atualizada" : "cadastrada"} com sucesso`,
    });
  };

  const handleEdit = (plantacao: Plantacao) => {
    setFormData({
      cultura: plantacao.cultura,
      area: plantacao.area.toString(),
      dataPlantio: plantacao.dataPlantio,
      variedade: plantacao.variedade,
      status: plantacao.status,
      previsaoColheita: plantacao.previsaoColheita,
    });
    setEditingId(plantacao.id);
    setIsFormOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta plantação?")) {
      deletePlantacao(id);
      loadPlantacoes();
      toast({
        title: "Plantação excluída",
        description: "A plantação foi removida com sucesso",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      cultura: "",
      area: "",
      dataPlantio: "",
      variedade: "",
      status: "plantado",
      previsaoColheita: "",
    });
    setEditingId(null);
    setIsFormOpen(false);
  };

  const statusColors = {
    plantado: "bg-info",
    crescimento: "bg-warning",
    colhido: "bg-success",
  };

  const statusLabels = {
    plantado: "Plantado",
    crescimento: "Em Crescimento",
    colhido: "Colhido",
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Plantações</h1>
          <p className="text-muted-foreground">Gerencie suas áreas de plantio</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Plantação
        </Button>
      </div>

      {isFormOpen && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? "Editar" : "Nova"} Plantação</CardTitle>
            <CardDescription>
              Preencha os dados da plantação
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cultura">Cultura *</Label>
                  <Input
                    id="cultura"
                    value={formData.cultura}
                    onChange={(e) => setFormData({ ...formData, cultura: e.target.value })}
                    placeholder="Ex: Milho, Soja, Trigo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variedade">Variedade *</Label>
                  <Input
                    id="variedade"
                    value={formData.variedade}
                    onChange={(e) => setFormData({ ...formData, variedade: e.target.value })}
                    placeholder="Ex: BRS 1030"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="area">Área (hectares) *</Label>
                  <Input
                    id="area"
                    type="number"
                    step="0.01"
                    value={formData.area}
                    onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataPlantio">Data de Plantio *</Label>
                  <Input
                    id="dataPlantio"
                    type="date"
                    value={formData.dataPlantio}
                    onChange={(e) => setFormData({ ...formData, dataPlantio: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="previsaoColheita">Previsão de Colheita *</Label>
                  <Input
                    id="previsaoColheita"
                    type="date"
                    value={formData.previsaoColheita}
                    onChange={(e) => setFormData({ ...formData, previsaoColheita: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value: any) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="plantado">Plantado</SelectItem>
                      <SelectItem value="crescimento">Em Crescimento</SelectItem>
                      <SelectItem value="colhido">Colhido</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-2">
                <Button type="submit">{editingId ? "Atualizar" : "Cadastrar"}</Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancelar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {plantacoes.length === 0 ? (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Sprout className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Nenhuma plantação cadastrada</p>
            </CardContent>
          </Card>
        ) : (
          plantacoes.map((plantacao) => (
            <Card key={plantacao.id} className="hover-scale">
              <CardHeader>
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Sprout className="h-4 w-4 text-primary" />
                      <span className="truncate">{plantacao.cultura}</span>
                    </CardTitle>
                    <CardDescription className="truncate">{plantacao.variedade}</CardDescription>
                  </div>
                  <Badge className={statusColors[plantacao.status]}>
                    {statusLabels[plantacao.status]}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-sm">
                  <span className="text-muted-foreground">Área: </span>
                  <span className="font-medium">{plantacao.area} ha</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Plantio: </span>
                  <span>{new Date(plantacao.dataPlantio).toLocaleDateString()}</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Previsão: </span>
                  <span>{new Date(plantacao.previsaoColheita).toLocaleDateString()}</span>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(plantacao)}>
                    <Edit className="h-3 w-3 mr-1" />
                    Editar
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDelete(plantacao.id)}
                  >
                    <Trash2 className="h-3 w-3 mr-1" />
                    Excluir
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default Plantacoes;
