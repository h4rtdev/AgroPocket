import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { History, Sprout, Package, TrendingUp, Plus, Edit, Trash2 } from "lucide-react";
import { getHistorico, HistoricoOperacao } from "@/lib/storage";
import { Badge } from "@/components/ui/badge";

const Historico = () => {
  const [historico, setHistorico] = useState<HistoricoOperacao[]>([]);

  useEffect(() => {
    loadHistorico();
    // Refresh every 5 seconds
    const interval = setInterval(loadHistorico, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadHistorico = () => {
    setHistorico(getHistorico());
  };

  const getIcon = (tipo: string) => {
    switch (tipo) {
      case "plantacao":
        return Sprout;
      case "insumo":
        return Package;
      case "colheita":
        return TrendingUp;
      default:
        return History;
    }
  };

  const getAcaoIcon = (acao: string) => {
    switch (acao) {
      case "criar":
        return Plus;
      case "editar":
        return Edit;
      case "excluir":
        return Trash2;
      default:
        return History;
    }
  };

  const tipoColors = {
    plantacao: "bg-primary",
    insumo: "bg-secondary",
    colheita: "bg-success",
  };

  const acaoColors = {
    criar: "bg-success",
    editar: "bg-info",
    excluir: "bg-destructive",
  };

  const tipoLabels = {
    plantacao: "Plantação",
    insumo: "Insumo",
    colheita: "Colheita",
  };

  const acaoLabels = {
    criar: "Criação",
    editar: "Edição",
    excluir: "Exclusão",
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `Há ${days} dia${days > 1 ? "s" : ""}`;
    } else if (hours > 0) {
      return `Há ${hours} hora${hours > 1 ? "s" : ""}`;
    } else if (minutes > 0) {
      return `Há ${minutes} minuto${minutes > 1 ? "s" : ""}`;
    } else {
      return "Agora mesmo";
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Histórico de Operações</h1>
        <p className="text-muted-foreground">
          Acompanhe todas as atividades realizadas no sistema
        </p>
      </div>

      {historico.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <History className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Nenhuma operação registrada</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {historico.map((item) => {
            const TipoIcon = getIcon(item.tipo);
            const AcaoIcon = getAcaoIcon(item.acao);

            return (
              <Card key={item.id} className="hover-scale">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="mt-1">
                        <TipoIcon className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-base font-medium">
                          {item.descricao}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {formatDate(item.data)}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Badge className={tipoColors[item.tipo]}>
                        {tipoLabels[item.tipo]}
                      </Badge>
                      <Badge className={acaoColors[item.acao]} variant="outline">
                        <AcaoIcon className="h-3 w-3 mr-1" />
                        {acaoLabels[item.acao]}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Historico;
