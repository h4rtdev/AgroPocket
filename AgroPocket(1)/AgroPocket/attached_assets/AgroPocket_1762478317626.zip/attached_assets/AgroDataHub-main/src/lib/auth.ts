export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  user?: User;
}

const USERS_KEY = 'farmdata_users';
const CURRENT_USER_KEY = 'farmdata_current_user';

export const authStorage = {
  // Registrar novo usuário
  register: (email: string, password: string, name: string): AuthResponse => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    
    // Verificar se email já existe
    if (users.find((u: any) => u.email === email)) {
      return { success: false, message: 'Email já cadastrado' };
    }

    // Validações
    if (!email || !password || !name) {
      return { success: false, message: 'Todos os campos são obrigatórios' };
    }

    if (password.length < 6) {
      return { success: false, message: 'Senha deve ter no mínimo 6 caracteres' };
    }

    const newUser: User = {
      id: crypto.randomUUID(),
      email,
      name,
      createdAt: new Date().toISOString(),
    };

    // Salvar usuário com senha (em produção, use hash)
    const userWithPassword = { ...newUser, password };
    users.push(userWithPassword);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));

    return { success: true, message: 'Cadastro realizado com sucesso! Faça login para acessar o sistema.', user: newUser };
  },

  // Login
  login: (email: string, password: string): AuthResponse => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    
    const user = users.find((u: any) => u.email === email && u.password === password);

    if (!user) {
      return { success: false, message: 'Email ou senha incorretos' };
    }

    const { password: _, ...userWithoutPassword } = user;
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userWithoutPassword));

    return { success: true, message: 'Login realizado com sucesso!', user: userWithoutPassword };
  },

  // Logout
  logout: (): void => {
    localStorage.removeItem(CURRENT_USER_KEY);
  },

  // Obter usuário atual
  getCurrentUser: (): User | null => {
    const user = localStorage.getItem(CURRENT_USER_KEY);
    return user ? JSON.parse(user) : null;
  },

  // Verificar se está autenticado
  isAuthenticated: (): boolean => {
    return !!authStorage.getCurrentUser();
  },
};
