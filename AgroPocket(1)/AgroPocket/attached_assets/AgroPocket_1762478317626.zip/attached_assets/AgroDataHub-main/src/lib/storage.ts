// LocalStorage utility functions for data persistence

export interface Plantacao {
  id: string;
  cultura: string;
  area: number;
  dataPlantio: string;
  variedade: string;
  status: "plantado" | "crescimento" | "colhido";
  previsaoColheita: string;
}

export interface Insumo {
  id: string;
  nome: string;
  tipo: "fertilizante" | "defensivo" | "sementes" | "outros";
  quantidade: number;
  unidade: string;
  fornecedor: string;
  dataCompra: string;
  valorUnitario: number;
}

export interface Colheita {
  id: string;
  plantacaoId: string;
  cultura: string;
  dataColheita: string;
  quantidade: number;
  unidade: string;
  qualidade: "excelente" | "boa" | "regular" | "ruim";
  observacoes: string;
}

export interface HistoricoOperacao {
  id: string;
  tipo: "plantacao" | "insumo" | "colheita";
  acao: "criar" | "editar" | "excluir";
  descricao: string;
  data: string;
}

const STORAGE_KEYS = {
  PLANTACOES: "agrodatahub_plantacoes",
  INSUMOS: "agrodatahub_insumos",
  COLHEITAS: "agrodatahub_colheitas",
  HISTORICO: "agrodatahub_historico",
};

// Generic storage functions
function getFromStorage<T>(key: string): T[] {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading ${key} from storage:`, error);
    return [];
  }
}

function saveToStorage<T>(key: string, data: T[]): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving ${key} to storage:`, error);
  }
}

// Plantações
export const getPlantacoes = (): Plantacao[] => getFromStorage<Plantacao>(STORAGE_KEYS.PLANTACOES);

export const savePlantacao = (plantacao: Plantacao): void => {
  const plantacoes = getPlantacoes();
  const index = plantacoes.findIndex((p) => p.id === plantacao.id);
  if (index !== -1) {
    plantacoes[index] = plantacao;
    addHistorico({
      id: Date.now().toString(),
      tipo: "plantacao",
      acao: "editar",
      descricao: `Plantação de ${plantacao.cultura} atualizada`,
      data: new Date().toISOString(),
    });
  } else {
    plantacoes.push(plantacao);
    addHistorico({
      id: Date.now().toString(),
      tipo: "plantacao",
      acao: "criar",
      descricao: `Nova plantação de ${plantacao.cultura} cadastrada`,
      data: new Date().toISOString(),
    });
  }
  saveToStorage(STORAGE_KEYS.PLANTACOES, plantacoes);
};

export const deletePlantacao = (id: string): void => {
  const plantacoes = getPlantacoes();
  const plantacao = plantacoes.find((p) => p.id === id);
  const filtered = plantacoes.filter((p) => p.id !== id);
  saveToStorage(STORAGE_KEYS.PLANTACOES, filtered);
  if (plantacao) {
    addHistorico({
      id: Date.now().toString(),
      tipo: "plantacao",
      acao: "excluir",
      descricao: `Plantação de ${plantacao.cultura} removida`,
      data: new Date().toISOString(),
    });
  }
};

// Insumos
export const getInsumos = (): Insumo[] => getFromStorage<Insumo>(STORAGE_KEYS.INSUMOS);

export const saveInsumo = (insumo: Insumo): void => {
  const insumos = getInsumos();
  const index = insumos.findIndex((i) => i.id === insumo.id);
  if (index !== -1) {
    insumos[index] = insumo;
    addHistorico({
      id: Date.now().toString(),
      tipo: "insumo",
      acao: "editar",
      descricao: `Insumo ${insumo.nome} atualizado`,
      data: new Date().toISOString(),
    });
  } else {
    insumos.push(insumo);
    addHistorico({
      id: Date.now().toString(),
      tipo: "insumo",
      acao: "criar",
      descricao: `Novo insumo ${insumo.nome} cadastrado`,
      data: new Date().toISOString(),
    });
  }
  saveToStorage(STORAGE_KEYS.INSUMOS, insumos);
};

export const deleteInsumo = (id: string): void => {
  const insumos = getInsumos();
  const insumo = insumos.find((i) => i.id === id);
  const filtered = insumos.filter((i) => i.id !== id);
  saveToStorage(STORAGE_KEYS.INSUMOS, filtered);
  if (insumo) {
    addHistorico({
      id: Date.now().toString(),
      tipo: "insumo",
      acao: "excluir",
      descricao: `Insumo ${insumo.nome} removido`,
      data: new Date().toISOString(),
    });
  }
};

// Colheitas
export const getColheitas = (): Colheita[] => getFromStorage<Colheita>(STORAGE_KEYS.COLHEITAS);

export const saveColheita = (colheita: Colheita): void => {
  const colheitas = getColheitas();
  const index = colheitas.findIndex((c) => c.id === colheita.id);
  if (index !== -1) {
    colheitas[index] = colheita;
    addHistorico({
      id: Date.now().toString(),
      tipo: "colheita",
      acao: "editar",
      descricao: `Colheita de ${colheita.cultura} atualizada`,
      data: new Date().toISOString(),
    });
  } else {
    colheitas.push(colheita);
    addHistorico({
      id: Date.now().toString(),
      tipo: "colheita",
      acao: "criar",
      descricao: `Nova colheita de ${colheita.cultura} registrada`,
      data: new Date().toISOString(),
    });
  }
  saveToStorage(STORAGE_KEYS.COLHEITAS, colheitas);
};

export const deleteColheita = (id: string): void => {
  const colheitas = getColheitas();
  const colheita = colheitas.find((c) => c.id === id);
  const filtered = colheitas.filter((c) => c.id !== id);
  saveToStorage(STORAGE_KEYS.COLHEITAS, filtered);
  if (colheita) {
    addHistorico({
      id: Date.now().toString(),
      tipo: "colheita",
      acao: "excluir",
      descricao: `Colheita de ${colheita.cultura} removida`,
      data: new Date().toISOString(),
    });
  }
};

// Histórico
export const getHistorico = (): HistoricoOperacao[] =>
  getFromStorage<HistoricoOperacao>(STORAGE_KEYS.HISTORICO);

const addHistorico = (operacao: HistoricoOperacao): void => {
  const historico = getHistorico();
  historico.unshift(operacao); // Add to beginning
  // Keep only last 100 entries
  const limited = historico.slice(0, 100);
  saveToStorage(STORAGE_KEYS.HISTORICO, limited);
};

export const clearAllData = (): void => {
  Object.values(STORAGE_KEYS).forEach((key) => {
    localStorage.removeItem(key);
  });
  addHistorico({
    id: Date.now().toString(),
    tipo: "plantacao",
    acao: "excluir",
    descricao: "Todos os dados foram limpos",
    data: new Date().toISOString(),
  });
};
