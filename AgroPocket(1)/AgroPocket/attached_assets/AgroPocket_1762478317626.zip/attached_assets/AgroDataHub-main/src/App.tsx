import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";
import Dashboard from "./pages/Dashboard";
import Plantacoes from "./pages/Plantacoes";
import Insumos from "./pages/Insumos";
import Colheitas from "./pages/Colheitas";
import Historico from "./pages/Historico";
import Documentacao from "./pages/Documentacao";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/auth" element={<Auth />} />
          <Route path="/" element={<ProtectedRoute><Layout><Dashboard /></Layout></ProtectedRoute>} />
          <Route path="/plantacoes" element={<ProtectedRoute><Layout><Plantacoes /></Layout></ProtectedRoute>} />
          <Route path="/insumos" element={<ProtectedRoute><Layout><Insumos /></Layout></ProtectedRoute>} />
          <Route path="/colheitas" element={<ProtectedRoute><Layout><Colheitas /></Layout></ProtectedRoute>} />
          <Route path="/historico" element={<ProtectedRoute><Layout><Historico /></Layout></ProtectedRoute>} />
          <Route path="/documentacao" element={<ProtectedRoute><Layout><Documentacao /></Layout></ProtectedRoute>} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
