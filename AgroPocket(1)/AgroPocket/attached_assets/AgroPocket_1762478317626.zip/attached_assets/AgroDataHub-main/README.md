# Bem-vindo aoAgroPocket

## Informações do projeto

**URL**: https://lovable.dev/projects/f1dac30c-e575-4021-9013-69fc71bc55cc

## Como posso editar este código?

Se você quiser trabalhar localmente usando sua própria IDE, você pode clonar este repositório e enviar mudanças. 

O único requisito é ter Node.js & npm instalados - [instalar com nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Siga estes passos:

```sh
# Passo 1: Clone o repositório usando a URL Git do projeto.
git clone <YOUR_GIT_URL>

# Passo 2: Navegue até o diretório do projeto.
cd <YOUR_PROJECT_NAME>

# Passo 3: Instale as dependências necessárias.
npm i

# Passo 4: Inicie o servidor de desenvolvimento com auto-reload e preview instantâneo.
npm run dev
```

**Editar um arquivo diretamente no GitHub**

- Navegue até o(s) arquivo(s) desejado(s)
- Clique no botão "Edit" (ícone de lápis) no canto superior direito da visualização do arquivo
- Faça suas alterações e commit as mudanças

**Usar GitHub Codespaces**

- Navegue até a página principal do seu repositório
- Clique no botão "Code" (botão verde) perto do canto superior direito
- Selecione a aba "Codespaces"
- Clique em "New codespace" para iniciar um novo ambiente Codespace
- Edite arquivos diretamente dentro do Codespace e faça commit e push das suas alterações quando terminar

## Quais tecnologias são usadas neste projeto?

Este projeto é construído com:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

