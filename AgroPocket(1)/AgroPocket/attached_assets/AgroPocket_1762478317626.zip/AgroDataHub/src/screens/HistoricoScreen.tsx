import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Card, Text, List } from 'react-native-paper';
import { getHistorico } from '../lib/storage';
import { HistoricoOperacao } from '../types';
import { format } from 'date-fns';

export default function HistoricoScreen() {
  const [historico, setHistorico] = useState<HistoricoOperacao[]>([]);

  useEffect(() => {
    loadHistorico();
  }, []);

  const loadHistorico = async () => {
    const data = await getHistorico();
    setHistorico(data);
  };

  const getIconForTipo = (tipo: string) => {
    switch (tipo) {
      case 'plantacao': return 'sprout';
      case 'insumo': return 'package-variant';
      case 'colheita': return 'chart-line';
      default: return 'file-document';
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {historico.length === 0 ? (
          <Card style={styles.emptyCard}>
            <Card.Content>
              <Text variant="titleMedium" style={styles.emptyText}>
                Nenhuma operação registrada
              </Text>
              <Text variant="bodyMedium" style={styles.emptySubtext}>
                As atividades do sistema aparecerão aqui
              </Text>
            </Card.Content>
          </Card>
        ) : (
          <Card style={styles.card}>
            <Card.Content>
              {historico.map((item) => (
                <List.Item
                  key={item.id}
                  title={item.descricao}
                  description={new Date(item.data).toLocaleString('pt-BR')}
                  left={(props) => <List.Icon {...props} icon={getIconForTipo(item.tipo)} />}
                />
              ))}
            </Card.Content>
          </Card>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  card: {
    marginBottom: 12,
  },
  emptyCard: {
    marginTop: 40,
  },
  emptyText: {
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtext: {
    textAlign: 'center',
    color: '#6b7280',
  },
});
