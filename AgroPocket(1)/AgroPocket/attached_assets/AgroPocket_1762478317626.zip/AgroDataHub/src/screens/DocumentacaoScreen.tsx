import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Card, Text, List } from 'react-native-paper';

export default function DocumentacaoScreen() {
  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <Card style={styles.card}>
          <Card.Title title="Sobre o AgroPocket" />
          <Card.Content>
            <Text variant="bodyMedium" style={styles.text}>
              O AgroPocket é uma solução completa para gerenciar suas operações agrícolas de forma simples e eficiente.
            </Text>
          </Card.Content>
        </Card>

        <Card style={styles.card}>
          <Card.Title title="Funcionalidades" />
          <Card.Content>
            <List.Item
              title="Plantações"
              description="Registre e acompanhe suas áreas de plantio"
              left={(props) => <List.Icon {...props} icon="sprout" />}
            />
            <List.Item
              title="Insumos"
              description="Controle seu estoque de fertilizantes e defensivos"
              left={(props) => <List.Icon {...props} icon="package-variant" />}
            />
            <List.Item
              title="Colheitas"
              description="Monitore suas colheitas e produtividade"
              left={(props) => <List.Icon {...props} icon="chart-line" />}
            />
            <List.Item
              title="Histórico"
              description="Acompanhe todas as operações registradas"
              left={(props) => <List.Icon {...props} icon="history" />}
            />
          </Card.Content>
        </Card>

        <Card style={styles.card}>
          <Card.Title title="Como Usar" />
          <Card.Content>
            <Text variant="bodyMedium" style={styles.text}>
              1. Comece cadastrando suas plantações{'\n'}
              2. Registre os insumos utilizados{'\n'}
              3. Acompanhe o crescimento das culturas{'\n'}
              4. Registre as colheitas realizadas{'\n'}
              5. Consulte o histórico de todas as operações
            </Text>
          </Card.Content>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  card: {
    marginBottom: 16,
  },
  text: {
    lineHeight: 24,
  },
});
