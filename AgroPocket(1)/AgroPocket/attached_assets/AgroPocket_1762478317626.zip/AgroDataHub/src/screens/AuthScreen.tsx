import React, { useState } from 'react';
import { View, StyleSheet, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { TextInput, Button, Text, Card, SegmentedButtons } from 'react-native-paper';
import Toast from 'react-native-toast-message';
import { useAuth } from '../lib/AuthContext';

export default function AuthScreen() {
  const { login, register } = useAuth();
  const [activeTab, setActiveTab] = useState('login');
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({ 
    name: '', 
    email: '', 
    password: '', 
    confirmPassword: '' 
  });
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    const result = await login(loginData.email, loginData.password);
    setLoading(false);

    if (result.success) {
      Toast.show({
        type: 'success',
        text1: 'Sucesso!',
        text2: result.message,
      });
    } else {
      Toast.show({
        type: 'error',
        text1: 'Erro',
        text2: result.message,
      });
    }
  };

  const handleRegister = async () => {
    if (registerData.password !== registerData.confirmPassword) {
      Toast.show({
        type: 'error',
        text1: 'Erro',
        text2: 'As senhas não coincidem',
      });
      return;
    }

    setLoading(true);
    const result = await register(
      registerData.email,
      registerData.password,
      registerData.name
    );
    setLoading(false);

    if (result.success) {
      Toast.show({
        type: 'success',
        text1: 'Sucesso!',
        text2: result.message,
      });
      setRegisterData({ name: '', email: '', password: '', confirmPassword: '' });
      setActiveTab('login');
    } else {
      Toast.show({
        type: 'error',
        text1: 'Erro',
        text2: result.message,
      });
    }
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Text variant="displaySmall" style={styles.title}>🌱 AgroPocket</Text>
          <Text variant="bodyLarge" style={styles.subtitle}>Sistema de Gestão Agrícola</Text>
        </View>

        <Card style={styles.card}>
          <Card.Content>
            <SegmentedButtons
              value={activeTab}
              onValueChange={setActiveTab}
              buttons={[
                { value: 'login', label: 'Entrar' },
                { value: 'register', label: 'Cadastrar' },
              ]}
              style={styles.segmentedButtons}
            />

            {activeTab === 'login' ? (
              <View style={styles.form}>
                <TextInput
                  label="Email"
                  value={loginData.email}
                  onChangeText={(email) => setLoginData({ ...loginData, email })}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  mode="outlined"
                  style={styles.input}
                />
                <TextInput
                  label="Senha"
                  value={loginData.password}
                  onChangeText={(password) => setLoginData({ ...loginData, password })}
                  secureTextEntry
                  mode="outlined"
                  style={styles.input}
                />
                <Button 
                  mode="contained" 
                  onPress={handleLogin}
                  loading={loading}
                  disabled={loading}
                  style={styles.button}
                >
                  Entrar
                </Button>
              </View>
            ) : (
              <View style={styles.form}>
                <TextInput
                  label="Nome"
                  value={registerData.name}
                  onChangeText={(name) => setRegisterData({ ...registerData, name })}
                  mode="outlined"
                  style={styles.input}
                />
                <TextInput
                  label="Email"
                  value={registerData.email}
                  onChangeText={(email) => setRegisterData({ ...registerData, email })}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  mode="outlined"
                  style={styles.input}
                />
                <TextInput
                  label="Senha"
                  value={registerData.password}
                  onChangeText={(password) => setRegisterData({ ...registerData, password })}
                  secureTextEntry
                  mode="outlined"
                  style={styles.input}
                />
                <TextInput
                  label="Confirmar Senha"
                  value={registerData.confirmPassword}
                  onChangeText={(confirmPassword) => 
                    setRegisterData({ ...registerData, confirmPassword })
                  }
                  secureTextEntry
                  mode="outlined"
                  style={styles.input}
                />
                <Button 
                  mode="contained" 
                  onPress={handleRegister}
                  loading={loading}
                  disabled={loading}
                  style={styles.button}
                >
                  Cadastrar
                </Button>
              </View>
            )}
          </Card.Content>
        </Card>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0fdf4',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  title: {
    fontWeight: 'bold',
    color: '#059669',
    marginBottom: 8,
  },
  subtitle: {
    color: '#6b7280',
  },
  card: {
    elevation: 4,
  },
  segmentedButtons: {
    marginBottom: 20,
  },
  form: {
    gap: 12,
  },
  input: {
    marginBottom: 8,
  },
  button: {
    marginTop: 8,
  },
});
