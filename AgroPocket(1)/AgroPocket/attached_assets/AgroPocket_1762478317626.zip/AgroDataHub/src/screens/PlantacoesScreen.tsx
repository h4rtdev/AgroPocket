import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, FlatList } from 'react-native';
import { Card, Text, FAB, Portal, Modal, TextInput, Button, Chip } from 'react-native-paper';
import { getPlantacoes, savePlantacao, deletePlantacao } from '../lib/storage';
import { Plantacao } from '../types';
import Toast from 'react-native-toast-message';
import { format } from 'date-fns';

export default function PlantacoesScreen() {
  const [plantacoes, setPlantacoes] = useState<Plantacao[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [formData, setFormData] = useState<Partial<Plantacao>>({
    cultura: '',
    area: 0,
    variedade: '',
    status: 'plantado',
    dataPlantio: new Date().toISOString().split('T')[0],
    previsaoColheita: '',
  });

  useEffect(() => {
    loadPlantacoes();
  }, []);

  const loadPlantacoes = async () => {
    const data = await getPlantacoes();
    setPlantacoes(data);
  };

  const handleSave = async () => {
    if (!formData.cultura || !formData.area) {
      Toast.show({
        type: 'error',
        text1: 'Erro',
        text2: 'Preencha os campos obrigatórios',
      });
      return;
    }

    const plantacao: Plantacao = {
      id: formData.id || Date.now().toString(),
      cultura: formData.cultura!,
      area: formData.area!,
      variedade: formData.variedade || '',
      status: formData.status as any || 'plantado',
      dataPlantio: formData.dataPlantio || new Date().toISOString().split('T')[0],
      previsaoColheita: formData.previsaoColheita || '',
    };

    await savePlantacao(plantacao);
    Toast.show({
      type: 'success',
      text1: 'Sucesso',
      text2: 'Plantação salva com sucesso!',
    });
    setModalVisible(false);
    resetForm();
    loadPlantacoes();
  };

  const handleDelete = async (id: string) => {
    await deletePlantacao(id);
    Toast.show({
      type: 'success',
      text1: 'Sucesso',
      text2: 'Plantação removida!',
    });
    loadPlantacoes();
  };

  const resetForm = () => {
    setFormData({
      cultura: '',
      area: 0,
      variedade: '',
      status: 'plantado',
      dataPlantio: new Date().toISOString().split('T')[0],
      previsaoColheita: '',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'plantado': return '#dcfce7';
      case 'crescimento': return '#fef3c7';
      case 'colhido': return '#dbeafe';
      default: return '#f3f4f6';
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {plantacoes.length === 0 ? (
          <Card style={styles.emptyCard}>
            <Card.Content>
              <Text variant="titleMedium" style={styles.emptyText}>
                Nenhuma plantação cadastrada
              </Text>
              <Text variant="bodyMedium" style={styles.emptySubtext}>
                Toque no botão + para adicionar sua primeira plantação
              </Text>
            </Card.Content>
          </Card>
        ) : (
          plantacoes.map((item) => (
            <Card key={item.id} style={styles.card}>
              <Card.Content>
                <View style={styles.cardHeader}>
                  <Text variant="titleLarge">{item.cultura}</Text>
                  <Chip style={{ backgroundColor: getStatusColor(item.status) }}>
                    {item.status}
                  </Chip>
                </View>
                <Text variant="bodyMedium">Variedade: {item.variedade}</Text>
                <Text variant="bodyMedium">Área: {item.area} hectares</Text>
                <Text variant="bodySmall">Plantio: {item.dataPlantio}</Text>
                {item.previsaoColheita && (
                  <Text variant="bodySmall">Previsão de colheita: {item.previsaoColheita}</Text>
                )}
              </Card.Content>
              <Card.Actions>
                <Button onPress={() => handleDelete(item.id)}>Excluir</Button>
              </Card.Actions>
            </Card>
          ))
        )}
      </ScrollView>

      <Portal>
        <Modal
          visible={modalVisible}
          onDismiss={() => setModalVisible(false)}
          contentContainerStyle={styles.modal}
        >
          <Text variant="titleLarge" style={styles.modalTitle}>Nova Plantação</Text>
          <TextInput
            label="Cultura *"
            value={formData.cultura}
            onChangeText={(cultura) => setFormData({ ...formData, cultura })}
            mode="outlined"
            style={styles.input}
          />
          <TextInput
            label="Área (hectares) *"
            value={formData.area?.toString()}
            onChangeText={(area) => setFormData({ ...formData, area: parseFloat(area) || 0 })}
            keyboardType="numeric"
            mode="outlined"
            style={styles.input}
          />
          <TextInput
            label="Variedade"
            value={formData.variedade}
            onChangeText={(variedade) => setFormData({ ...formData, variedade })}
            mode="outlined"
            style={styles.input}
          />
          <TextInput
            label="Previsão de Colheita"
            value={formData.previsaoColheita}
            onChangeText={(previsaoColheita) => setFormData({ ...formData, previsaoColheita })}
            mode="outlined"
            style={styles.input}
            placeholder="YYYY-MM-DD"
          />
          <View style={styles.modalActions}>
            <Button onPress={() => setModalVisible(false)}>Cancelar</Button>
            <Button mode="contained" onPress={handleSave}>Salvar</Button>
          </View>
        </Modal>
      </Portal>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => {
          resetForm();
          setModalVisible(true);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  card: {
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  emptyCard: {
    marginTop: 40,
  },
  emptyText: {
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtext: {
    textAlign: 'center',
    color: '#6b7280',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: '#059669',
  },
  modal: {
    backgroundColor: 'white',
    padding: 20,
    margin: 20,
    borderRadius: 8,
  },
  modalTitle: {
    marginBottom: 16,
  },
  input: {
    marginBottom: 12,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 8,
    marginTop: 8,
  },
});
