import AsyncStorage from '@react-native-async-storage/async-storage';
import { User, AuthResponse } from '../types';

const USERS_KEY = 'farmdata_users';
const CURRENT_USER_KEY = 'farmdata_current_user';

export const authStorage = {
  register: async (email: string, password: string, name: string): Promise<AuthResponse> => {
    try {
      const usersData = await AsyncStorage.getItem(USERS_KEY);
      const users = usersData ? JSON.parse(usersData) : [];

      if (users.find((u: any) => u.email === email)) {
        return { success: false, message: 'Email já cadastrado' };
      }

      if (!email || !password || !name) {
        return { success: false, message: 'Todos os campos são obrigatórios' };
      }

      if (password.length < 6) {
        return { success: false, message: 'Senha deve ter no mínimo 6 caracteres' };
      }

      const newUser: User = {
        id: Date.now().toString(),
        email,
        name,
        createdAt: new Date().toISOString(),
      };

      const userWithPassword = { ...newUser, password };
      users.push(userWithPassword);
      await AsyncStorage.setItem(USERS_KEY, JSON.stringify(users));

      return {
        success: true,
        message: 'Cadastro realizado com sucesso! Faça login para acessar o sistema.',
        user: newUser,
      };
    } catch (error) {
      return { success: false, message: 'Erro ao registrar usuário' };
    }
  },

  login: async (email: string, password: string): Promise<AuthResponse> => {
    try {
      const usersData = await AsyncStorage.getItem(USERS_KEY);
      const users = usersData ? JSON.parse(usersData) : [];

      const user = users.find((u: any) => u.email === email && u.password === password);

      if (!user) {
        return { success: false, message: 'Email ou senha incorretos' };
      }

      const { password: _, ...userWithoutPassword } = user;
      await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userWithoutPassword));

      return { success: true, message: 'Login realizado com sucesso!', user: userWithoutPassword };
    } catch (error) {
      return { success: false, message: 'Erro ao fazer login' };
    }
  },

  logout: async (): Promise<void> => {
    try {
      await AsyncStorage.removeItem(CURRENT_USER_KEY);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  },

  getCurrentUser: async (): Promise<User | null> => {
    try {
      const user = await AsyncStorage.getItem(CURRENT_USER_KEY);
      return user ? JSON.parse(user) : null;
    } catch (error) {
      return null;
    }
  },

  isAuthenticated: async (): Promise<boolean> => {
    try {
      const user = await authStorage.getCurrentUser();
      return !!user;
    } catch (error) {
      return false;
    }
  },
};
