import AsyncStorage from '@react-native-async-storage/async-storage';
import { Plantacao, Insumo, Colheita, HistoricoOperacao } from '../types';

const STORAGE_KEYS = {
  PLANTACOES: 'agrodatahub_plantacoes',
  INSUMOS: 'agrodatahub_insumos',
  COLHEITAS: 'agrodatahub_colheitas',
  HISTORICO: 'agrodatahub_historico',
};

async function getFromStorage<T>(key: string): Promise<T[]> {
  try {
    const data = await AsyncStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error(`Error reading ${key} from storage:`, error);
    return [];
  }
}

async function saveToStorage<T>(key: string, data: T[]): Promise<void> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error saving ${key} to storage:`, error);
  }
}

export const getPlantacoes = (): Promise<Plantacao[]> =>
  getFromStorage<Plantacao>(STORAGE_KEYS.PLANTACOES);

export const savePlantacao = async (plantacao: Plantacao): Promise<void> => {
  const plantacoes = await getPlantacoes();
  const index = plantacoes.findIndex((p) => p.id === plantacao.id);
  if (index !== -1) {
    plantacoes[index] = plantacao;
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'plantacao',
      acao: 'editar',
      descricao: `Plantação de ${plantacao.cultura} atualizada`,
      data: new Date().toISOString(),
    });
  } else {
    plantacoes.push(plantacao);
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'plantacao',
      acao: 'criar',
      descricao: `Nova plantação de ${plantacao.cultura} cadastrada`,
      data: new Date().toISOString(),
    });
  }
  await saveToStorage(STORAGE_KEYS.PLANTACOES, plantacoes);
};

export const deletePlantacao = async (id: string): Promise<void> => {
  const plantacoes = await getPlantacoes();
  const plantacao = plantacoes.find((p) => p.id === id);
  const filtered = plantacoes.filter((p) => p.id !== id);
  await saveToStorage(STORAGE_KEYS.PLANTACOES, filtered);
  if (plantacao) {
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'plantacao',
      acao: 'excluir',
      descricao: `Plantação de ${plantacao.cultura} removida`,
      data: new Date().toISOString(),
    });
  }
};

export const getInsumos = (): Promise<Insumo[]> => getFromStorage<Insumo>(STORAGE_KEYS.INSUMOS);

export const saveInsumo = async (insumo: Insumo): Promise<void> => {
  const insumos = await getInsumos();
  const index = insumos.findIndex((i) => i.id === insumo.id);
  if (index !== -1) {
    insumos[index] = insumo;
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'insumo',
      acao: 'editar',
      descricao: `Insumo ${insumo.nome} atualizado`,
      data: new Date().toISOString(),
    });
  } else {
    insumos.push(insumo);
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'insumo',
      acao: 'criar',
      descricao: `Novo insumo ${insumo.nome} cadastrado`,
      data: new Date().toISOString(),
    });
  }
  await saveToStorage(STORAGE_KEYS.INSUMOS, insumos);
};

export const deleteInsumo = async (id: string): Promise<void> => {
  const insumos = await getInsumos();
  const insumo = insumos.find((i) => i.id === id);
  const filtered = insumos.filter((i) => i.id !== id);
  await saveToStorage(STORAGE_KEYS.INSUMOS, filtered);
  if (insumo) {
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'insumo',
      acao: 'excluir',
      descricao: `Insumo ${insumo.nome} removido`,
      data: new Date().toISOString(),
    });
  }
};

export const getColheitas = (): Promise<Colheita[]> =>
  getFromStorage<Colheita>(STORAGE_KEYS.COLHEITAS);

export const saveColheita = async (colheita: Colheita): Promise<void> => {
  const colheitas = await getColheitas();
  const index = colheitas.findIndex((c) => c.id === colheita.id);
  if (index !== -1) {
    colheitas[index] = colheita;
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'colheita',
      acao: 'editar',
      descricao: `Colheita de ${colheita.cultura} atualizada`,
      data: new Date().toISOString(),
    });
  } else {
    colheitas.push(colheita);
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'colheita',
      acao: 'criar',
      descricao: `Nova colheita de ${colheita.cultura} registrada`,
      data: new Date().toISOString(),
    });
  }
  await saveToStorage(STORAGE_KEYS.COLHEITAS, colheitas);
};

export const deleteColheita = async (id: string): Promise<void> => {
  const colheitas = await getColheitas();
  const colheita = colheitas.find((c) => c.id === id);
  const filtered = colheitas.filter((c) => c.id !== id);
  await saveToStorage(STORAGE_KEYS.COLHEITAS, filtered);
  if (colheita) {
    await addHistorico({
      id: Date.now().toString(),
      tipo: 'colheita',
      acao: 'excluir',
      descricao: `Colheita de ${colheita.cultura} removida`,
      data: new Date().toISOString(),
    });
  }
};

export const getHistorico = (): Promise<HistoricoOperacao[]> =>
  getFromStorage<HistoricoOperacao>(STORAGE_KEYS.HISTORICO);

const addHistorico = async (operacao: HistoricoOperacao): Promise<void> => {
  const historico = await getHistorico();
  historico.unshift(operacao);
  const limited = historico.slice(0, 100);
  await saveToStorage(STORAGE_KEYS.HISTORICO, limited);
};

export const clearAllData = async (): Promise<void> => {
  await Promise.all(
    Object.values(STORAGE_KEYS).map((key) => AsyncStorage.removeItem(key))
  );
  await addHistorico({
    id: Date.now().toString(),
    tipo: 'plantacao',
    acao: 'excluir',
    descricao: 'Todos os dados foram limpos',
    data: new Date().toISOString(),
  });
};
