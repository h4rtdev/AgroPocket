export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  user?: User;
}

export interface Plantacao {
  id: string;
  cultura: string;
  area: number;
  dataPlantio: string;
  variedade: string;
  status: "plantado" | "crescimento" | "colhido";
  previsaoColheita: string;
}

export interface Insumo {
  id: string;
  nome: string;
  tipo: "fertilizante" | "defensivo" | "sementes" | "outros";
  quantidade: number;
  unidade: string;
  fornecedor: string;
  dataCompra: string;
  valorUnitario: number;
}

export interface Colheita {
  id: string;
  plantacaoId: string;
  cultura: string;
  dataColheita: string;
  quantidade: number;
  unidade: string;
  qualidade: "excelente" | "boa" | "regular" | "ruim";
  observacoes: string;
}

export interface HistoricoOperacao {
  id: string;
  tipo: "plantacao" | "insumo" | "colheita";
  acao: "criar" | "editar" | "excluir";
  descricao: string;
  data: string;
}
