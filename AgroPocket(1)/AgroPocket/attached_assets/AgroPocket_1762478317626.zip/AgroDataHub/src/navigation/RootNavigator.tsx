import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useAuth } from '../lib/AuthContext';
import { ActivityIndicator, View } from 'react-native';
import AuthScreen from '../screens/AuthScreen';
import DashboardScreen from '../screens/DashboardScreen';
import PlantacoesScreen from '../screens/PlantacoesScreen';
import InsumosScreen from '../screens/InsumosScreen';
import ColheitasScreen from '../screens/ColheitasScreen';
import HistoricoScreen from '../screens/HistoricoScreen';
import DocumentacaoScreen from '../screens/DocumentacaoScreen';

export type RootStackParamList = {
  Auth: undefined;
  Dashboard: undefined;
  Plantacoes: undefined;
  Insumos: undefined;
  Colheitas: undefined;
  Historico: undefined;
  Documentacao: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function RootNavigator() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#059669" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerShown: true,
          headerStyle: {
            backgroundColor: '#059669',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        {!isAuthenticated ? (
          <Stack.Screen 
            name="Auth" 
            component={AuthScreen} 
            options={{ headerShown: false }}
          />
        ) : (
          <>
            <Stack.Screen 
              name="Dashboard" 
              component={DashboardScreen}
              options={{ title: 'AgroPocket' }}
            />
            <Stack.Screen 
              name="Plantacoes" 
              component={PlantacoesScreen}
              options={{ title: 'Plantações' }}
            />
            <Stack.Screen 
              name="Insumos" 
              component={InsumosScreen}
              options={{ title: 'Insumos' }}
            />
            <Stack.Screen 
              name="Colheitas" 
              component={ColheitasScreen}
              options={{ title: 'Colheitas' }}
            />
            <Stack.Screen 
              name="Historico" 
              component={HistoricoScreen}
              options={{ title: 'Histórico' }}
            />
            <Stack.Screen 
              name="Documentacao" 
              component={DocumentacaoScreen}
              options={{ title: 'Documentação' }}
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
