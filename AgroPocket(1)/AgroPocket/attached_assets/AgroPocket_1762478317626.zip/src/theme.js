// Centralized theme for AgroPocket
export const COLORS = {
  background: '#000000',
  surface: '#1C1C1C',
  primary: '#00FF66', // verde neon
  accent: '#FFD700', // amarelo ouro
  text: '#FFFFFF',
  muted: '#B3B3B3',
  card: '#111111'
};

export default {
  COLORS,
  FONT_FAMILY: 'Poppins'
};
